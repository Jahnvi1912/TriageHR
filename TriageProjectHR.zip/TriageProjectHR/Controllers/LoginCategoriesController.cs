﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using TriageProjectHR.Models;

namespace TriageProjectHR.Controllers
{
    public class LoginCategoriesController : Controller
    {
        public static string fileName, email;
        private HRProjectDBContext db = new HRProjectDBContext();


        [HttpGet]
        public ActionResult Login()
        {
            ViewBag.CategoryID = new SelectList(db.LoginCategorys, "CategoryID", "CategoryName");

            return View();
        }
        [HttpPost]
        public ActionResult Login(Employee eMPLOYEE)
        {

            Employee mPLOYEE = db.Employees.FirstOrDefault(e => e.Email == eMPLOYEE.Email && e.Password == eMPLOYEE.Password);
            if (mPLOYEE.CategoryID == 4)
            {
                return RedirectToAction("Index");
            }
            else if (mPLOYEE != null)
            {
                //int ? id = mPLOYEE.EmployeeId;

                Session["UserId"] = mPLOYEE.EmployeeId;
                return RedirectToAction("AfterLogin", mPLOYEE);
            }
            else
            {
                ViewBag.Status = "Invalid user or password";
                return View();

            }
        }
        
        [HttpGet]
        public ActionResult AfterLogin(Employee mPLOYEE)
        {
            if (Session["UserId"] != null)
            {
                if (mPLOYEE == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Employee eMPLOYEE = db.Employees.Find(mPLOYEE.EmployeeId);
                if (eMPLOYEE == null)
                {
                    return HttpNotFound();
                }
                return View(eMPLOYEE);
            }
            else
            {
                return RedirectToAction("Login");
            }
        }

        public ActionResult LeaveStatus()
        {
            int EmployeeID = Convert.ToInt32(Session["UserID"]);
            var leaves = db.Leaves.Where(e => e.Employee.EmployeeId == EmployeeID).Include(l => l.Employee).Include(l => l.Status);
            return View(leaves.ToList());
            
        }

        [HttpGet]
        public ActionResult RequestLeave(int? id)
        {
            //int EmployeeID = Convert.ToInt32(Session["UserID"]);
            ViewBag.EmployeeId = new SelectList(db.Employees.Where(e => e.EmployeeId == id).ToList(), "EmployeeId", "EmployeeName");
            ViewBag.StatusID = new SelectList(db.Statuses.Where(s => s.StatusID == 1).ToList(), "StatusID", "StatusName");
            return View();
        }

        // POST: Leaves/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult RequestLeave([Bind(Include = "LeaveID,LeaveReason,LeaveDuration,StartDate,EndDate,EmployeeId,StatusID")] Leave leave)

        {
            if (ModelState.IsValid)
            {
                db.Leaves.Add(leave);
                db.SaveChanges();
                Employee employee = db.Employees.Find(leave.EmployeeId);
                return RedirectToAction("AfterLogin", employee);
            }

            ViewBag.EmployeeId = new SelectList(db.Employees, "EmployeeId", "EmployeeName", leave.EmployeeId);
            ViewBag.StatusID = new SelectList(db.Statuses, "StatusID", "StatusName", leave.StatusID);
            return View(leave);
        }

        

        public ActionResult TrainingStatus()
        {
            int EmployeeID = Convert.ToInt32(Session["UserID"]);
            var trainings = db.Trainings.Where(e => e.Employee.EmployeeId == EmployeeID).Include(l => l.Employee).Include(l => l.Status);
            return View(trainings.ToList());

        }
        public ActionResult UploadFile(HttpPostedFileBase file)
        {
            try
            {
                if (file.ContentLength > 0)
                {
                    string StrExt = Path.GetExtension(file.FileName);
                    fileName = "PROPIC" + DateTime.Now.ToString("ddMMyyyyHHmmss") + StrExt; // Path.GetFileName(file.FileName);
                    file.SaveAs(Server.MapPath("~/Upload/") + fileName);

                }
                ViewBag.Message = "File upload successfully!!";
                //Server.MapPath("~") + @"Content\Upload\"+ fileName;

                ViewBag.Path = String.Format("/Upload/{0}", fileName.Replace('+', '_'));
                //ViewBag.PicUrl =  "~/Upload/" + fileName;
                ViewBag.CategoryID = new SelectList(db.LoginCategorys.Where(c => c.CategoryID == 6).ToList(), "CategoryID", "CategoryName");
                ViewBag.DeptID = new SelectList(db.Departments, "DeptID", "DeptName");

                return View("EmployeeCreate");
            }
            catch (Exception)
            {
                ViewBag.Message = "File upload failed!";
                return View("EmployeeCreate");

            }
        }
        [HttpGet]
        public ActionResult EmployeeCreate()
        {
            //ViewBag.CategoryID = new SelectList(db.Categorys, "CategoryID", "CategoryName");

            ViewBag.CategoryID = new SelectList(db.LoginCategorys.Where(c => c.CategoryID == 6).ToList(), "CategoryID", "CategoryName");
            ViewBag.DeptID = new SelectList(db.Departments, "DeptID", "DeptName");
            return View();
        }
        // POST: Employees/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult EmployeeCreate([Bind(Include = "EmployeeId,EmployeeName,CategoryID,DeptID,Password,Contact,Email,ProfilePic,EmployeeDOB")] Employee employee)
        {
            if (ModelState.IsValid)
            {
                //employee.ProfilePic = "~/Upload/" + fileName;
                db.Employees.Add(employee);
                db.SaveChanges();
                return RedirectToAction("Login");
            }
            ViewBag.CategoryID = new SelectList(db.LoginCategorys, "CategoryID", "CategoryName", employee.CategoryID);
            ViewBag.DeptID = new SelectList(db.Departments, "DeptID", "DeptName", employee.DeptID);
            return View(employee);
        }



        // GET: LoginCategories
        public ActionResult Index()
        {
            return View(db.LoginCategorys.ToList());
        }

        // GET: LoginCategories/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            LoginCategory loginCategory = db.LoginCategorys.Find(id);
            if (loginCategory == null)
            {
                return HttpNotFound();
            }
            return View(loginCategory);
        }

        // GET: LoginCategories/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: LoginCategories/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "CategoryID,CategoryName")] LoginCategory loginCategory)
        {
            if (ModelState.IsValid)
            {
                db.LoginCategorys.Add(loginCategory);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(loginCategory);
        }

        // GET: LoginCategories/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            LoginCategory loginCategory = db.LoginCategorys.Find(id);
            if (loginCategory == null)
            {
                return HttpNotFound();
            }
            return View(loginCategory);
        }

        // POST: LoginCategories/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "CategoryID,CategoryName")] LoginCategory loginCategory)
        {
            if (ModelState.IsValid)
            {
                db.Entry(loginCategory).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(loginCategory);
        }

        // GET: LoginCategories/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            LoginCategory loginCategory = db.LoginCategorys.Find(id);
            if (loginCategory == null)
            {
                return HttpNotFound();
            }
            return View(loginCategory);
        }

        // POST: LoginCategories/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            LoginCategory loginCategory = db.LoginCategorys.Find(id);
            db.LoginCategorys.Remove(loginCategory);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}

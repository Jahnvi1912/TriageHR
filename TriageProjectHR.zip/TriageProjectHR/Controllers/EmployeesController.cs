﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.IO;
using System.Web;
using System.Web.Mvc;
using TriageProjectHR.Models;

namespace TriageProjectHR.Controllers
{
    public class EmployeesController : Controller
    {
        private HRProjectDBContext db = new HRProjectDBContext();
        public static string fileName, email;

        //[HttpGet]
        //public ActionResult RequestLeave(int? id)
        //{
        //    //int EmployeeID = Convert.ToInt32(Session["UserID"]);
        //    ViewBag.EmployeeId = new SelectList(db.Employees.Where(e=> e.EmployeeId==id).ToList(), "EmployeeId", "EmployeeName");
        //    ViewBag.StatusID = new SelectList(db.Statuses, "StatusID", "StatusName");
        //    return View();
        //}

        //// POST: Leaves/Create
        //// To protect from overposting attacks, enable the specific properties you want to bind to, for 
        //// more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public ActionResult RequestLeave([Bind(Include = "LeaveID,LeaveReason,LeaveDuration,StartDate,EndDate,EmployeeId,StatusID")] Leave leave)
          
        //{
        //    if (ModelState.IsValid)
        //    {
        //        db.Leaves.Add(leave);
        //        db.SaveChanges();
        //        return RedirectToAction("Index");
        //    }

        //    ViewBag.EmployeeId = new SelectList(db.Employees, "EmployeeId", "EmployeeName", leave.EmployeeId);
        //    ViewBag.StatusID = new SelectList(db.Statuses, "StatusID", "StatusName", leave.StatusID);
        //    return View(leave);
        //}
        // GET: Employees

        public ActionResult Index()
        {
            var employees = db.Employees.Include(e => e.Department).Include(e => e.LoginCategory);
            return View(employees.ToList());
        }

        public ActionResult ApplyLeave()
        {
            ViewBag.StatusID = new SelectList(db.Statuses.Where(s=> s.StatusID==1).ToList(), "StatusID", "StatusName");
            return View();
        }
        // GET: Employees/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Employee employee = db.Employees.Find(id);
            if (employee == null)
            {
                return HttpNotFound();
            }
            return View(employee);
        }

        public ActionResult EditUploadFile(HttpPostedFileBase file, int id)
        {
            Employee employee = db.Employees.Find(id);

            try
            {
                if (file.ContentLength > 0)
                {
                    string StrExt = Path.GetExtension(file.FileName);
                    fileName = "PROPIC" + DateTime.Now.ToString("ddMMyyyyHHmmss") + StrExt; // Path.GetFileName(file.FileName);
                    file.SaveAs(Server.MapPath("~/Upload/") + fileName);

                }
                ViewBag.Message = "File upload successfully!!";

                employee.ProfilePic = String.Format("/Upload/{0}", fileName.Replace('+', '_'));
                db.Entry(employee).State = EntityState.Modified;
                db.SaveChanges();

                //ViewBag.Path = String.Format("/Upload/{0}", fileName.Replace('+', '_'));

                //ViewBag.PicUrl =  "~/Upload/" + fileName;
                ViewBag.CategoryID = new SelectList(db.LoginCategorys, "CategoryID", "CategoryName");
                ViewBag.DeptID = new SelectList(db.Departments, "DeptID", "DeptName");
                return RedirectToAction("Edit/" + employee.EmployeeId);
            }
            catch (Exception)
            {
                ViewBag.Message = "File upload failed!";
                return RedirectToAction("Edit/" + employee.EmployeeId);

            }
        }
        public ActionResult UploadFile(HttpPostedFileBase file)
        {
            try
            {
                if (file.ContentLength > 0)
                {
                    string StrExt = Path.GetExtension(file.FileName);
                    fileName = "PROPIC" + DateTime.Now.ToString("ddMMyyyyHHmmss") + StrExt; // Path.GetFileName(file.FileName);
                    file.SaveAs(Server.MapPath("~/Upload/") + fileName);

                }
                ViewBag.Message = "File upload successfully!!";
                //Server.MapPath("~") + @"Content\Upload\"+ fileName;

                ViewBag.Path = String.Format("/Upload/{0}", fileName.Replace('+', '_'));
                //ViewBag.PicUrl =  "~/Upload/" + fileName;
                ViewBag.CategoryID = new SelectList(db.LoginCategorys, "CategoryID", "CategoryName");
                ViewBag.DeptID = new SelectList(db.Departments, "DeptID", "DeptName");
                return View("Create");
            }
            catch (Exception)
            {
                ViewBag.Message = "File upload failed!";
                return View("Create");

            }
        }
        // GET: Employees/Create
        public ActionResult Create()
        {
            ViewBag.DeptID = new SelectList(db.Departments, "DeptID", "DeptName");
            ViewBag.CategoryID = new SelectList(db.LoginCategorys, "CategoryID", "CategoryName");
            return View();
        }

        // POST: Employees/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "EmployeeId,EmployeeName,CategoryID,DeptID,Password,Contact,Email,ProfilePic,EmployeeDOB")] Employee employee)
        {
            if (ModelState.IsValid)
            {
                db.Employees.Add(employee);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.DeptID = new SelectList(db.Departments, "DeptID", "DeptName", employee.DeptID);
            ViewBag.CategoryID = new SelectList(db.LoginCategorys, "CategoryID", "CategoryName", employee.CategoryID);
            return View(employee);
        }

        // GET: Employees/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Employee employee = db.Employees.Find(id);
            if (employee == null)
            {
                return HttpNotFound();
            }
            ViewBag.DeptID = new SelectList(db.Departments, "DeptID", "DeptName", employee.DeptID);
            ViewBag.CategoryID = new SelectList(db.LoginCategorys, "CategoryID", "CategoryName", employee.CategoryID);
            return View(employee);
        }

        // POST: Employees/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "EmployeeId,EmployeeName,CategoryID,DeptID,Password,Contact,Email,ProfilePic,EmployeeDOB")] Employee employee)
        {
            if (ModelState.IsValid)
            {
                db.Entry(employee).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.DeptID = new SelectList(db.Departments, "DeptID", "DeptName", employee.DeptID);
            ViewBag.CategoryID = new SelectList(db.LoginCategorys, "CategoryID", "CategoryName", employee.CategoryID);
            return View(employee);
        }

        // GET: Employees/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Employee employee = db.Employees.Find(id);
            if (employee == null)
            {
                return HttpNotFound();
            }
            return View(employee);
        }

        // POST: Employees/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Employee employee = db.Employees.Find(id);
            db.Employees.Remove(employee);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}

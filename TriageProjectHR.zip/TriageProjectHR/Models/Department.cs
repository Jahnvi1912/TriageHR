﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TriageProjectHR.Models
{
    public class Department
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]

        public int DeptID { get; set; }
        [DisplayName("Department Name")]
        [Required(ErrorMessage = "Please Enter deparment name e.g. FINANCE")]
        [RegularExpression("^[A-Z ]{1,50}$")]
        public string DeptName { get; set; }
        [DisplayName("Department Location")]
        [Required(ErrorMessage = "Please Enter deparment location e.g. noida")]
        public string DeptLocation { get; set; }
        public virtual ICollection<Employee> Employees { get; set; }
    }
}
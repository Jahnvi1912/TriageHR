﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TriageProjectHR.Models
{
    public class Employee
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int EmployeeId { get; set; }

        [Required(ErrorMessage = "Please Enter Name e.g. ABCD ABCDEFGH")]
        [DisplayName("Employee Name")]
        [StringLength(30, MinimumLength = 10)]
        [RegularExpression("^[A-Z]{4,12} [A-Z]{4,12}$")]
        public string EmployeeName { get; set; }

        [ForeignKey("LoginCategory")]
        [Required(ErrorMessage = "Please select Category")]
        [DisplayName("Category")]
        [DefaultValue(3)]
        public int CategoryID { get; set; }

        [ForeignKey("Department")]
        [Required(ErrorMessage = "Please select department")]
        [DisplayName("Deparment")]
        public int DeptID { get; set; }

        [DisplayName("Password")]
        [Required(ErrorMessage = "Password should not be blank")]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        [DisplayName("Phone Number")]
        [RegularExpression("^[6-9]{1}[0-9]{9}$")]
        [Required(ErrorMessage = "Phone number should not be blank eg. +91 XXXXXXXXXX")]
        public string Contact { get; set; }

        [DisplayName("Email")]
        [Required(ErrorMessage = "Enter valid email address  Hint: example123@example.com")]
        [EmailAddress]
        public string Email { get; set; }

        [DisplayName("Profile Picture")]
        [Required(ErrorMessage = "Please select appropriate image")]
        public string ProfilePic { get; set; }

        [DisplayName("Date of birth")]
        [Required(ErrorMessage = "Date should not be blank")]
        [DataType(DataType.Date)]
        public DateTime? EmployeeDOB { get; set; }

        public virtual Department Department { get; set; }
        public virtual LoginCategory LoginCategory { get; set; }

        public virtual ICollection<Training> Trainings { get; set; }
        public virtual ICollection<Trainer> Trainers { get; set; }
        public virtual ICollection<Leave> Leaves { get; set; }
    }
}
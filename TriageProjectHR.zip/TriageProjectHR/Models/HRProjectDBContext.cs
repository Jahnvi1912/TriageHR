﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TriageProjectHR.Models
{
    public class HRProjectDBContext : DbContext
    {
        public HRProjectDBContext() : base("name=HRProjectConnString")
        {
            //ProjectDatabase
        }
        public virtual DbSet<LoginCategory> LoginCategorys { get; set; }
        public virtual DbSet<Department> Departments { get; set; }
        public virtual DbSet<Employee> Employees { get; set; }
        public virtual DbSet<Training> Trainings { get; set; }
        public virtual DbSet<Trainer> Trainers { get; set; }
        public virtual DbSet<Leave> Leaves { get; set; }
        public virtual DbSet<Status> Statuses { get; set; }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace TriageProjectHR.Models
{
    public class Leave
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int LeaveID { get; set; }
        [DisplayName("Leave Reason ")]
        [Required]
        public string LeaveReason { get; set; }

        public int LeaveDuration { get; set; }
        [DisplayName("Leave Start Date")]
        [Required(ErrorMessage = "Date should not be blank")]
        [DataType(DataType.Date)]
        public DateTime StartDate { get; set; }
        [DisplayName("Leave End Date")]
        [Required(ErrorMessage = "Date should not be blank")]
        [DataType(DataType.Date)]
        public DateTime EndDate { get; set; }

        [ForeignKey("Employee")]
        [Required(ErrorMessage = "Please select the employee")]
        [DisplayName("Employee")]
        public int EmployeeId { get; set; }
        [ForeignKey("Status")]
        [Required(ErrorMessage = "Please select the status")]
        [DisplayName("Leave Status")]
      
        public int StatusID { get; set; }
        public virtual Employee Employee { get; set; }
        public virtual Status Status { get; set; }
    }
}
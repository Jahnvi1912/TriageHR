﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TriageProjectHR.Models
{
    public class Trainer
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int TrainerID { get; set; }
        [DisplayName("Trainer Name")]
        [Required(ErrorMessage = "Please Enter trainer name e.g. DOTNET")]
        [RegularExpression("^[A-Z ]{1,50}$")]
        public string TrainerName { get; set; }

        [ForeignKey("Training")]
        [DisplayName("Training Name")]
        public int TrainingId { get; set; }

        [ForeignKey("Employee")]
        [DisplayName("Employee Name")]
        public int EmployeeId { get; set; }

        public virtual Employee Employee { get; set; }
        public virtual Training Training { get; set; }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TriageProjectHR.Models
{
    public class Training
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int TrainingId { get; set; }

        [DisplayName("Training Name")]
        [Required(ErrorMessage = "Please Enter training name e.g. DOTNET")]
        [RegularExpression("^[A-Z ]{1,50}$")]
        public string TrainingName { get; set; }

        public int TrainingDuration { get; set; }
        [DisplayName("Training Start Date")]
        [Required(ErrorMessage = "Date should not be blank")]
        [DataType(DataType.Date)]
        public DateTime StartDate { get; set; }
        [DisplayName("Training End Date")]
        [Required(ErrorMessage = "Date should not be blank")]
        [DataType(DataType.Date)]
        public DateTime EndDate { get; set; }

        [ForeignKey("Employee")]
        [Required(ErrorMessage = "Please select the manager")]
        [DisplayName("Project Manager")]
        public int EmployeeId { get; set; }
        [ForeignKey("Status")]
        [Required(ErrorMessage = "Please select the status")]
        [DisplayName("Training Status")]

        public int StatusID { get; set; }
        public virtual Employee Employee { get; set; }
        public virtual Status Status { get; set; }
        public virtual ICollection<Trainer> Trainers { get; set; }

    }
}
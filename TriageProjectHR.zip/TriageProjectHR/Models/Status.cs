﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace TriageProjectHR.Models
{
    public class Status
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]

        public int StatusID { get; set; }
        [DisplayName("Status Name")]
        [Required(ErrorMessage = "Please Enter category name e.g. PENDING")]
        [RegularExpression("^[A-Z]{1,20}$")]

        public string StatusName { get; set; }

        public virtual ICollection<Leave> Leaves
        {
            get; set;
        }

        public virtual ICollection<Training> Trainings
        {
            get; set;
        }
    }
}
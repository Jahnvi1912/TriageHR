﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TriageProjectHR.Models
{
    public class LoginCategory
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]

        public int CategoryID { get; set; }
        [DisplayName("Category Name")]
        [Required(ErrorMessage = "Please Enter category name e.g. EMPLOYEE")]
        [RegularExpression("^[A-Z]{1,20}$")]

        public string CategoryName { get; set; }

        public virtual ICollection<Employee> Employees
        {
            get; set;
        }
    }
}
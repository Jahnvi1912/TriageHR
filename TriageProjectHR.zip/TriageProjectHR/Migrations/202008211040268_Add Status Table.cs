﻿namespace TriageProjectHR.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddStatusTable : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Status",
                c => new
                    {
                        StatusID = c.Int(nullable: false, identity: true),
                        StatusName = c.String(nullable: false),
                    })
                .PrimaryKey(t => t.StatusID);
            
            AddColumn("dbo.Leaves", "StatusID", c => c.Int(nullable: false));
            CreateIndex("dbo.Leaves", "StatusID");
            AddForeignKey("dbo.Leaves", "StatusID", "dbo.Status", "StatusID", cascadeDelete: true);
            DropColumn("dbo.Leaves", "LeaveStatus");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Leaves", "LeaveStatus", c => c.Boolean(nullable: false));
            DropForeignKey("dbo.Leaves", "StatusID", "dbo.Status");
            DropIndex("dbo.Leaves", new[] { "StatusID" });
            DropColumn("dbo.Leaves", "StatusID");
            DropTable("dbo.Status");
        }
    }
}

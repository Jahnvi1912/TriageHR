﻿namespace TriageProjectHR.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class InitializeDatabase : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Departments",
                c => new
                    {
                        DeptID = c.Int(nullable: false, identity: true),
                        DeptName = c.String(nullable: false),
                        DeptLocation = c.String(nullable: false),
                    })
                .PrimaryKey(t => t.DeptID);
            
            CreateTable(
                "dbo.Employees",
                c => new
                    {
                        EmployeeId = c.Int(nullable: false, identity: true),
                        EmployeeName = c.String(nullable: false, maxLength: 30),
                        CategoryID = c.Int(nullable: false),
                        DeptID = c.Int(nullable: false),
                        Password = c.String(nullable: false),
                        Contact = c.String(nullable: false),
                        Email = c.String(nullable: false),
                        ProfilePic = c.String(nullable: false),
                        EmployeeDOB = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.EmployeeId)
                .ForeignKey("dbo.Departments", t => t.DeptID, cascadeDelete: false)
                .ForeignKey("dbo.LoginCategories", t => t.CategoryID, cascadeDelete: false)
                .Index(t => t.CategoryID)
                .Index(t => t.DeptID);
            
            CreateTable(
                "dbo.Leaves",
                c => new
                    {
                        LeaveID = c.Int(nullable: false, identity: true),
                        LeaveReason = c.String(nullable: false),
                        LeaveDuration = c.Int(nullable: false),
                        StartDate = c.DateTime(nullable: false),
                        EndDate = c.DateTime(nullable: false),
                        EmployeeId = c.Int(nullable: false),
                        LeaveStatus = c.Boolean(nullable: false),
                    })
                .PrimaryKey(t => t.LeaveID)
                .ForeignKey("dbo.Employees", t => t.EmployeeId, cascadeDelete: false)
                .Index(t => t.EmployeeId);
            
            CreateTable(
                "dbo.LoginCategories",
                c => new
                    {
                        CategoryID = c.Int(nullable: false, identity: true),
                        CategoryName = c.String(nullable: false),
                    })
                .PrimaryKey(t => t.CategoryID);
            
            CreateTable(
                "dbo.Trainers",
                c => new
                    {
                        TrainerID = c.Int(nullable: false, identity: true),
                        TrainerName = c.String(nullable: false),
                        TrainingId = c.Int(nullable: false),
                        EmployeeId = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.TrainerID)
                .ForeignKey("dbo.Employees", t => t.EmployeeId, cascadeDelete: false)
                .ForeignKey("dbo.Trainings", t => t.TrainingId, cascadeDelete: false)
                .Index(t => t.TrainingId)
                .Index(t => t.EmployeeId);
            
            CreateTable(
                "dbo.Trainings",
                c => new
                    {
                        TrainingId = c.Int(nullable: false, identity: true),
                        TrainingName = c.String(nullable: false),
                        TrainingDuration = c.Int(nullable: false),
                        StartDate = c.DateTime(nullable: false),
                        EndDate = c.DateTime(nullable: false),
                        EmployeeId = c.Int(nullable: false),
                        TrainingStatus = c.Boolean(nullable: false),
                    })
                .PrimaryKey(t => t.TrainingId)
                .ForeignKey("dbo.Employees", t => t.EmployeeId, cascadeDelete: false)
                .Index(t => t.EmployeeId);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Trainers", "TrainingId", "dbo.Trainings");
            DropForeignKey("dbo.Trainings", "EmployeeId", "dbo.Employees");
            DropForeignKey("dbo.Trainers", "EmployeeId", "dbo.Employees");
            DropForeignKey("dbo.Employees", "CategoryID", "dbo.LoginCategories");
            DropForeignKey("dbo.Leaves", "EmployeeId", "dbo.Employees");
            DropForeignKey("dbo.Employees", "DeptID", "dbo.Departments");
            DropIndex("dbo.Trainings", new[] { "EmployeeId" });
            DropIndex("dbo.Trainers", new[] { "EmployeeId" });
            DropIndex("dbo.Trainers", new[] { "TrainingId" });
            DropIndex("dbo.Leaves", new[] { "EmployeeId" });
            DropIndex("dbo.Employees", new[] { "DeptID" });
            DropIndex("dbo.Employees", new[] { "CategoryID" });
            DropTable("dbo.Trainings");
            DropTable("dbo.Trainers");
            DropTable("dbo.LoginCategories");
            DropTable("dbo.Leaves");
            DropTable("dbo.Employees");
            DropTable("dbo.Departments");
        }
    }
}

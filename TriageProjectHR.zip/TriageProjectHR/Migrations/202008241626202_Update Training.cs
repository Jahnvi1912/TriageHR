﻿namespace TriageProjectHR.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class UpdateTraining : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Trainings", "StatusID", c => c.Int(nullable: false));
            CreateIndex("dbo.Trainings", "StatusID");
            AddForeignKey("dbo.Trainings", "StatusID", "dbo.Status", "StatusID", cascadeDelete: true);
            DropColumn("dbo.Trainings", "TrainingStatus");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Trainings", "TrainingStatus", c => c.Boolean(nullable: false));
            DropForeignKey("dbo.Trainings", "StatusID", "dbo.Status");
            DropIndex("dbo.Trainings", new[] { "StatusID" });
            DropColumn("dbo.Trainings", "StatusID");
        }
    }
}
